
export default [
    {
        id: "agaqgvsnvcr",
        catagory: "Combo Deal",
        dishes: [
            {
                id: "5upamd9mzi4",
                name: "Combo 1",
                price: "99.00"
            },
            {
                id: "pgb86xr8u76",
                name: "Combo 2",
                price: "199.00"
            },
            {
                id: "3xd0zk3cmti",
                name: "Combo 3",
                price: "299.00"
            }
        ]
    },
    {
        id: "z8dsfj4tps5",
        catagory: "Appetizers",
        dishes: [
            {
                id: "r63lgrb1ely",
                name: "French Fries",
                price: "100.00"
            },
            {
                id: "bxx1kzzts4e",
                name: "Masala Wedges",
                price: "80.00"
            }
        ]
    },
    {
        id: "95u90dd7zbk",
        catagory: "Noodles",
        dishes: [
            {
                id: "80a4twp9uk6",
                name: "Egg Noodles",
                price: "80.00"
            },
            {
                id: "e0eiowxd8bb",
                name: "Vegetable Noodles",
                price: "110.00"
            },
            {
                id: "ajdodjwg5ej",
                name: "Chicken Noodles",
                price: "150.00"
            }
        ]
    },
    {
        id: "lgd81pcav5z",
        catagory: "Pasta",
        dishes: [
            {
                id: "u7wxtgyhvzj",
                name: "Egg Pasta",
                price: "120.00"
            },
            {
                id: "fntp074ldla",
                name: "Chicken Pasta",
                price: "150.00"
            },
            {
                id: "dwfqdxqldf2",
                name: "Chicken Sausage Pasta",
                price: "200.00"
            }
        ]
    },
    {
        id: "6jfnwhqz84f",
        catagory: "Chicken Burger",
        dishes: [
            {
                id: "r23eu8kcd6o",
                name: "Mini Chicken Burger",
                price: "90.00"
            },
            {
                id: "0dywf3rypd0",
                name: "Chicken Burger",
                price: "130.00"
            },
            {
                id: "m10f1ejqv46",
                name: "Chicken Cheese Burger",
                price: "160.00"
            },
            {
                id: "t4d59vqd7js",
                name: "BBQ Chicken Burger",
                price: "160.00"
            },
            {
                id: "xbf15xf0igx",
                name: "BBQ Chicken Cheese Burger",
                price: "170.00"
            },
            {
                id: "fmz0mketjux",
                name: "BBQ Chicken Cheese Sausage Burger",
                price: "200.00"
            },
            {
                id: "tjty1w09kup",
                name: "Chicken Cheese Delight Burger",
                price: "250.00"
            },
            {
                id: "r8tm7x8fr3g",
                name: "AJ Special Chicken Burger",
                price: "280.00"
            }
        ]
    },

]