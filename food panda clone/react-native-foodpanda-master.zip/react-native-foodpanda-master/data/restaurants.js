export default [
    {
        title: "Bismillah Biryani House - Ahmed Nagar",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/t2fl-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Mayer Badhon Biryani House - Kallyanpur",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/u4ji-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Western Grill",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/s4xz-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Bismillah Biryani House - Kallyanpur Notun Bazar",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/t4fh-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Bismillah Biryani House - Kallyanpur",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/t3lx-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Al-Madina Biryani House - Mirpur",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/u4vx-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Kamal Biryani House - 60 Feet",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/g3jc-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Abir Tehari Ghar",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/u1qn-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Kallyanpur Kacchi Ghor",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/u1wu-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Coffee Club",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/u4df-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Kacchi Khor - Mirpur",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/t5ws-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Crazy Burger - Mirpur",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/u2km-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "The Burger Hub - Mirpur",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/l1it-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Terracotta Restaurant - Mirpur",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/u5bl-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Home Chef",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/u1dt-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Al-Baik Chicken",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/y3tx-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "The Berlin Cafe",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/t2pt-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Priyojon Bangla Restora",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/t1zq-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Dhaka Kitchen",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/s8le-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Indian Kashmiri Biryani House",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/u3zu-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Arju Biryani and Restaurant",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/t1xy-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Food Biology",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/t3tw-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Cake Zone",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/t8wd-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Rezia Pushpaloy",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/t9mv-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Kiyan's Kitchen",
        image: "https://images.deliveryhero.io/image/fd-bd/LH/t4he-listing.jpg?width=400&height=292",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    }
]