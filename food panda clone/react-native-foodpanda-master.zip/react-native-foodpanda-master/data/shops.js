export default [
    {
        title: "Shwapno",
        image: "https://asia-public.foodpanda.com/marketing/production/bd/images/nl/Logo_Shwapno_3.png?v=1459522734",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Bengal Meat",
        image: "https://asia-public.foodpanda.com/marketing/production/bd/images/nl/Bengal%20Meat%20Logo.png?v=1459522734",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Lazz Pharma Ltd.",
        image: "https://asia-public.foodpanda.com/marketing/production/bd/images/nl/Lazz%20Pharma_Logo%202.%20png.jpg?v=1459522734",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Unimart",
        image: "https://asia-public.foodpanda.com/marketing/production/bd/images/nl/Unimart%20logo.png?v=1459522734",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Little India - Grocery Store",
        image: "https://asia-public.foodpanda.com/marketing/production/bd/im…-of-vegetables-on-display-1508666%20%281%29.jpg?v=1459522734",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Abdullah Vegetables Store",
        image: "https://asia-public.foodpanda.com/marketing/production/bd/images/nl/assorted-vegetable-lot-1300972.jpg?v=1459522734",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "IFAD Multi Products LTD.",
        image: "https://asia-public.foodpanda.com/marketing/production/bd/images/nl/IFAD%20Multiproducts.png?v=1459522734",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    },
    {
        title: "Suborno Safe Vegetables",
        image: "https://asia-public.foodpanda.com/marketing/production/bd/im…49221_739556939559702_3892757590704898577_n.jpg?v=1459522734",
        description: "$$$ Rice Beverage Biryani Bangladeshi"
    }
]