# cloned Foodpanda Mobile App Using React Native
[APP LINK](https://drive.google.com/file/d/18LXrZZrifsWijqYwbKHR9MqAbUUX1Iey/view?usp=drivesdk)

![gif](https://drive.google.com/uc?export=view&id=18UbhEBfmKtjfpSRGO8fqhw7neVw1_HK7)
